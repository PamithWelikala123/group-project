<h1>Home page view</h1>

<img src="<?=ROOT?>/assets/images/logo.png">