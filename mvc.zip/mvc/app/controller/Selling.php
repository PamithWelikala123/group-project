<?php

//Selling class
class Selling{

    use Controller;
    public function index()
    {
        if ($_SESSION['USER']) {
            $postitem = new postitems;
            $arr['user_id'] = $_SESSION['USER']->user_id;
            $rows = $postitem->where($arr);
            if ($rows) {
                $this->view('selling', $rows);
            } else {
                $this->view('selling');
            }

            $this->view('selling', $rows);
        }
        else{
            redirect('login');
        }
    }


}

