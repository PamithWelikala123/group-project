<?php

//Feed class
class Feed{

    use Controller;
    public function index(){
    $postitem = new postitems;
    $rows = $postitem->findAll();

        $this->view('feed',$rows);
    }

}

