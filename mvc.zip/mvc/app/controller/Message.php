<?php

//Message class
class Message{

use Controller;
public function index(){

    
    $this->view('message');
}

}