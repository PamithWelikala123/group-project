<?php

//Buyer class
class Buyersignup{

    use Controller;
    public function index(){

        $this->view('buyersignup');
    }

}
