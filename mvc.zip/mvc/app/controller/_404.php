<?php

class _404 {
    use controller;

    public function index(){

        echo "404 page not found controller";
    }
}